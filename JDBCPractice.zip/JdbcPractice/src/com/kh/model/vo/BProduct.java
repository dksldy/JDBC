package com.kh.model.vo;

import java.util.Date;

public class BProduct {

	private int No;
	private int BNo;
	private int Amount;
	private String Status;
	private Date BDate;
	
	public BProduct() {
		super();
	}

	public BProduct(int no, int bNo, int amount, String status, Date bDate) {
		super();
		No = no;
		BNo = bNo;
		Amount = amount;
		Status = status;
		BDate = bDate;
	}

	public int getNo() {
		return No;
	}
	public void setNo(int no) {
		No = no;
	}
	public int getBNo() {
		return BNo;
	}
	public void setBNo(int bNo) {
		BNo = bNo;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Date getBDate() {
		return BDate;
	}
	public void setBDate(Date bDate) {
		BDate = bDate;
	}

	@Override
	public String toString() {
		return "BProduct [" + No + ", \t" + BNo + ", \t" + Amount + ", \t" + Status + ", \t" + BDate
				+ "]";
	}
	
	
}
