package com.kh.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.common.JDBCTemplate;
import com.kh.model.dao.ProductDao;
import com.kh.model.vo.BProduct;
import com.kh.model.vo.Product;


public class ProductService {
	public int insertProduct(Product p) {
		Connection conn = JDBCTemplate.getConnection();
		int result = new ProductDao().insertProduct(conn, p);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		return result;
	}
	
	public int insertBProduct(BProduct bp) {
		Connection conn = JDBCTemplate.getConnection();
		int result = new ProductDao().insertBProduct(conn, bp);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		return result;
	}
	
	public ArrayList<Product> selectList(){
		Connection conn = JDBCTemplate.getConnection();
		ArrayList<Product> list = new ProductDao().selectList(conn);
		JDBCTemplate.close(conn);
		return list;
	}
	
	public Product selectById(Product p) {
		Connection conn = JDBCTemplate.getConnection();
		Product product = new ProductDao().selectById(conn, p);
		JDBCTemplate.close(conn);
		return product;
	}
	
	public int updateById(Product p) {
		Connection conn = JDBCTemplate.getConnection();
		int result = new ProductDao().updateById(conn, p);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		return result;
	}
	
	public int deleteById(Product p) {
		Connection conn = JDBCTemplate.getConnection();
		int result = new ProductDao().deleteById(conn, p);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		return result;
	}
	
	public ArrayList<Product> selectByName(Product p){
		Connection conn = JDBCTemplate.getConnection();
		ArrayList<Product> list = new ProductDao().selectByName(conn, p);
		JDBCTemplate.close(conn);
		return list;	
	}
}