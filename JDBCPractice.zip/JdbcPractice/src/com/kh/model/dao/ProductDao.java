package com.kh.model.dao;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

import com.kh.common.JDBCTemplate;
import com.kh.model.vo.BProduct;
import com.kh.model.vo.Product;

public class ProductDao {
	private Properties prop;
	
	
	public ProductDao() {
		prop = new Properties();
		try {
			prop.loadFromXML(new FileInputStream("resources/query.xml"));
		} catch (InvalidPropertiesFormatException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public int insertProduct(Connection conn, Product p) {
			PreparedStatement pstmt = null;
			int result = 0; 
			
			try {
				String sql = prop.getProperty("INSERT_PRODUCT");
				
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, p.getProductId());
				pstmt.setString(2, p.getPName());
				pstmt.setInt(3, p.getPrice());
				pstmt.setString(4, p.getDescription());
				pstmt.setInt(5, p.getStock());
				
				result = pstmt.executeUpdate();
				
				if(result > 0) {
					JDBCTemplate.commit(conn);
				}else {
					JDBCTemplate.rollback(conn);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCTemplate.close(pstmt);
				JDBCTemplate.close(conn);
			}
		return result;
	}
	
	public int insertBProduct(Connection conn, BProduct p) {
		PreparedStatement pstmt = null;
		int result = 0; 
		
		try {
			String sql = prop.getProperty("INSERT_B_PRODUCT");
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, p.getNo());
			pstmt.setInt(2, p.getAmount());
			pstmt.setString(3, p.getStatus());
			
			result = pstmt.executeUpdate();
			
			if(result > 0) {
				JDBCTemplate.commit(conn);
			}else {
				JDBCTemplate.rollback(conn);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(conn);
		}
	return result;
}
	
	public ArrayList<Product> selectList(Connection conn){
			Statement stmt = null;
			ResultSet rset = null;
			ArrayList<Product> list = new ArrayList<Product>();
			
			try {
				conn.setAutoCommit(false);
				
				stmt = conn.createStatement();
				
				String sql = prop.getProperty("SELECT_LIST");
				
				rset = stmt.executeQuery(sql);
				
				while(rset.next()) {
					 Product p = new Product(
							 rset.getInt("NO"),
							 rset.getString("PRODUCT_ID"),
							 rset.getString("P_NAME"), 
							 rset.getInt("PRICE"),
							 rset.getString("DESCRIPTION"),
							 rset.getInt("STOCK"),
							 rset.getDate("ENROLLDATE")
							 );
					 list.add(p);
				} // End Of While
			
			} catch (SQLException e) {
				e.printStackTrace();
			} finally{
				JDBCTemplate.close(rset);
				JDBCTemplate.close(stmt);
				JDBCTemplate.close(conn);
				try {
					rset.close();
					stmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return list;
	}
	public Product selectById(Connection conn, Product p) {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Product product = null;
		
		try {
			String sql = prop.getProperty("SELECT_BY_ID");

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p.getProductId());
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				 product  = new Product(
						 rset.getInt("NO"),
						 rset.getString("PRODUCT_ID"),
						 rset.getString("P_NAME"), 
						 rset.getInt("PRICE"),
						 rset.getString("DESCRIPTION"),
						 rset.getInt("STOCK"),
						 rset.getDate("ENROLLDATE")
						 );
			} // End Of If
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return product;
	}
	public int updateById(Connection conn, Product p) {
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			String sql = prop.getProperty("UPDATE_BY_ID");
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,p.getPName());
			pstmt.setInt(2, p.getPrice());
			pstmt.setString(3, p.getDescription());
			pstmt.setString(4, p.getProductId());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			try {
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	return result;
	}
	public int deleteById(Connection conn, Product p) {
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			String sql = prop.getProperty("DELETE_BY_ID");
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, p.getProductId());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			try {
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	return result;
	}
	public ArrayList<Product> selectByName(Connection conn, Product p) {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Product> list = new ArrayList<Product>();
		
		try {
			String sql = prop.getProperty("SELECT_BY_NAME");
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p.getPName());
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				Product _p = new Product(
					rset.getInt("NO"),
					rset.getString("PRODUCT_ID"),
					rset.getString("P_NAME"), 
					rset.getInt("PRICE"),
					rset.getString("DESCRIPTION"),
					rset.getInt("STOCK"),
					rset.getDate("ENROLLDATE")
					);
				 list.add(_p);
			} // End Of While
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return list;
	}
}