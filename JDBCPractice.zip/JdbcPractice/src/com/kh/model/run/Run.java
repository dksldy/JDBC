package com.kh.model.run;

import com.kh.view.ProductView;

public class Run {

	public static void main(String[] args) {

		new ProductView().mainMenu();
		System.out.println("종료");
	}

}
