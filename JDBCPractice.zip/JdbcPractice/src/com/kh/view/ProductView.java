package com.kh.view;


import java.util.ArrayList;
import java.util.Scanner;

import com.kh.controller.ProductController;
import com.kh.model.vo.Product;


public class ProductView {
	private Scanner sc = new Scanner(System.in);
	private ProductController controller = new ProductController();
	public void mainMenu() {
		while (true) {
			System.out.println("==== 상품관리 ====");
			System.out.println("1. 상품 등록 : ");
			System.out.println("2. 상품 추가 : ");
			System.out.println("3. 현재 재고 조회 : ");
			System.out.println("4. 상품 검색(Id) : ");
			System.out.println("5. 상품 정보 수정(Id) : ");
			System.out.println("6. 등록 상품 삭제(Id) : ");
			System.out.println("7. 상품 검색(Name) : ");
			System.out.println("0. 프로그램 종료 : ");
			System.out.print("번호 입력 : ");
			int menu = Integer.parseInt(sc.nextLine());
	
			switch (menu) {
			case 1:
				insertProduct();
				break;
			case 2:
				insertBProduct();
				break;
			case 3:
				selectList();
				break;
			case 4:
				selectById();
				break;
			case 5:
				updateProduct();
				break;
			case 6:
				deleteProduct();
				break;
			case 7:
				selectByName();
				break;
			case 0:
				System.out.println("프로그램 종료");
				return;
			default:
				System.out.println("잘못된 번호입니다.");
			}
		}
	}
	
	private void insertProduct() {
		System.out.println("==== 상품 등록 ====");
		
		System.out.print("ProductId 입력 : ");
		String ProductId = sc.nextLine();
		
		System.out.print("PName 입력 : ");
		String PName = sc.nextLine();
		
		System.out.print("Price 입력 : ");
		int Price = Integer.parseInt(sc.nextLine());
		
		System.out.print("Description 입력 : ");
		String Description = sc.nextLine();
		
		System.out.print("Stock 입력 : ");
		int Stock = Integer.parseInt(sc.nextLine());
		
		controller.insertProduct(ProductId, PName, Price, Description, Stock);
	}
	
	private void insertBProduct() {
		System.out.println("==== 상품 추가 ====");
		
		System.out.print("No(상품번호) 입력 : ");
		int No = Integer.parseInt(sc.nextLine());
		
		System.out.print("Amount(개수) 입력 : ");
		int Amount = Integer.parseInt(sc.nextLine());
		
		System.out.print("Status('입고', '출고') 입력 : ");
		String Status = sc.nextLine();
		
		controller.insertBProduct(No, Amount, Status);
	}
	
	private void selectList() {
		System.out.println("==== 현재 재고 조회 =====");
		controller.selectList();
	}
	
	private void selectById() {
		System.out.println("==== 상품 검색(Id) ====");
		System.out.print("ProductId 입력 :");
		String ProductId = sc.nextLine();
		controller.selectById(ProductId);
	}
	
	private void updateProduct() {
		System.out.println("==== 상품 정보 수정(Id) =====");
		
		System.out.print("ProductId 입력 : ");
		String ProductId = sc.nextLine();
		
		System.out.print("PName 입력 : ");
		String PName = sc.nextLine();
		
		System.out.print("Price 입력 : ");
		int Price = Integer.parseInt(sc.nextLine());
		
		System.out.print("Description 입력 : ");
		String Description = sc.nextLine();
		
		controller.updateById(ProductId, PName, Price, Description);
	}
	
	private void deleteProduct() {
		System.out.println("==== 등록 상품 삭제(Id) ====");
		
		System.out.print("ProductId 입력 : ");
		String ProductId = sc.nextLine();
		
		controller.deleteById(ProductId);
	}
	
	private void selectByName() {
		System.out.println("==== 상품 검색(Name) ====");
		System.out.println("PName 입력 : ");
		String PName = sc.nextLine();
		
		controller.selectByName(PName);
	}
	
	public void displaySuccess(String message) {
		System.out.println("서비스 요청 성공 : " + message);
	};

	public void displayFailed(String message) {
		System.out.println("서비스 요청 실패 : " + message);
	};

	public void displayNoData(String message) {
		System.out.println("데이터 요청 결과 : " + message);
	};

	public void displayMemberList(ArrayList<Product> list) {
		
		for(Product p : list) {
			System.out.println(p.toString());
		}
	};

	public void displayMember(Product p) {
		System.out.println("조회된 상품 : " + p.toString());
	};
	
	
	
	
	
}