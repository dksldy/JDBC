package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.service.ProductService;
import com.kh.model.vo.BProduct;
import com.kh.model.vo.Product;
import com.kh.view.ProductView;

public class ProductController {
	   public void insertProduct(String ProductId, String PName, 
			   int Price, String Description, int Stock) {
		   
		   Product p = new Product();
		   p.setProductId(ProductId);
		   p.setPName(PName);
		   p.setPrice(Price);
		   p.setDescription(Description);
		   p.setStock(Stock);
		   
		   int result = new ProductService().insertProduct(p);
		   
		   if(result > 0) {
			   new ProductView().displaySuccess(PName + 
					   						" 상품등록이 완료되었습니다.");
		   }else {
			   new ProductView().displayFailed("상품등록 실패");
		   }
	   }
	   
	   public void insertBProduct(int No, int Amount, 
			   String Status) {
		   
		   BProduct bp = new BProduct();
		   bp.setNo(No);
		   bp.setAmount(Amount);
		   bp.setStatus(Status);
		   
		   int result = new ProductService().insertBProduct(bp);
		   
		   if(result > 0) {
			   new ProductView().displaySuccess("요청이 완료되었습니다.");
		   }else {
			   new ProductView().displayFailed("요청 실패");
		   }
	   }
	   
	   public void selectList() {
		   ArrayList<Product> list = new ProductService().selectList();
		   
		   if(list.isEmpty()) {
			   new ProductView().displayNoData("상품정보가 없습니다.");
		   }else{
			   new ProductView().displayMemberList(list);
		   }
	   }
	   
	   public void selectById(String ProductId) {
		   Product p = new Product();
		   p.setProductId(ProductId);
		   
		   Product product = new ProductService().selectById(p);
		   
		   if(product == null) {
			   new ProductView().displayFailed("해당 " + ProductId + 
					   						" 에 해당하는 정보가 없습니다.");
		   }else{
			   new ProductView().displaySuccess(ProductId + "상품 정보" + 
					   product);
		   }
	   }
	   
	   public void updateById(String ProductId, String PName, 
			   int Price, String Description) {
		   
		   Product p = new Product();
		   p.setProductId(ProductId);
		   p.setPName(PName);
		   p.setPrice(Price);
		   p.setDescription(Description);
		   
		   int result = new ProductService().updateById(p);
		   
		   if(result > 0) {
			   new ProductView().displaySuccess(PName + 
					   						"상품 정보수정이 완료되었습니다.");
		   }else {
			   new ProductView().displayFailed(PName + 
					   								" 상품 정보수정 실패");
		   }
	   }
	   
	   public void deleteById(String ProductId) { 
		   
		   Product p = new Product();
		   p.setProductId(ProductId);
		   
		   int result = new ProductService().deleteById(p);
		   
		   if(result > 0) {
			   new ProductView().displaySuccess(ProductId + 
					   						"의 상품 정보가 삭제되었습니다.");
		   }else {
			   new ProductView().displayFailed(ProductId + 
					   							"의 상품 정보 삭제 실패");
		   }
	   }
	   
	   public ArrayList<Product> selectByName(String PName){
		   Product p = new Product();
		   p.setPName(PName);
		   ArrayList<Product> list = new ProductService().selectByName(p);
		   
		   if(list.isEmpty()) {
			   new ProductView().displayNoData(PName + "에 대한 데이터정보가 없습니다.");
		   }else{
			   new ProductView().displayMemberList(list);
		   }
		   return null;
	   }
	   
}