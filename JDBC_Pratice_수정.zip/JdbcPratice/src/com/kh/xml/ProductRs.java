package com.kh.xml;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ProductRs {
	
	
	public static void main(String[] args) {
//		JdbcSettingTest();
//		jdbcgettingTest();
		JdbcSettingXmlTest();
		jdbcGettingXmlTest();
		System.out.println("The end");
	}

	public static void JdbcSettingTest() {
		
		File dir = new File("resources");
		if (!dir.exists()) {
		    dir.mkdirs(); 
		}

		Properties prop = new Properties();
		
		prop.setProperty("DRIVER", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("URL", "jdbc:oracle:thin:@127.0.0.1:1521:xe");
		prop.setProperty("ID", "C##KH");
		prop.setProperty("PASSWORD", "KH");
		
		try {
			prop.store(new FileOutputStream("resources/driver.properties"), "JDBC.Setting");
			prop.storeToXML(new FileOutputStream("resources/driver.xml"), "JDBC.Setting");

			System.out.println("jdbc 설정파일 driver.properties 성공");
		} catch (FileNotFoundException e) {
			System.out.println("파일위치 못찾음");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일내용 입력하는데 문제발생");
			e.printStackTrace();
		}
	}
	
	public static void jdbcgettingTest() {
		Properties prop = new Properties();
		
		try {
			prop.load(new FileInputStream("resources/driver.properties"));
		
			String driver = prop.getProperty("DRIVER");
			String url = prop.getProperty("URL");
			String id = prop.getProperty("ID");
			String password = prop.getProperty("PASSWORD");
			
			System.out.println("driver : " + driver);
			System.out.println("url : " + url);
			System.out.println("id : " + id);
			System.out.println("password : " + password);
			
		} catch (FileNotFoundException e) {
			System.out.println("파일위치 못찾음");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일내용 입력하는데 문제발생");
			e.printStackTrace();
		}
	}
	
	public static void JdbcSettingXmlTest() {
		Properties prop = new Properties();
		
		prop.setProperty("INSERT_PRODUCT", "INSERT INTO PRODUCT (NO, PRODUCT_ID, P_NAME, PRICE, DESCRIPTION,STOCK,ENROLLDATE)\r\n"
				+ "VALUES(SEQ_NO.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE)");
		prop.setProperty("INSERT_B_PRODUCT", "INSERT INTO BACK_PRODUCT (B_NO, NO, B_DATE, AMOUNT, STATUS)\r\n"
				+ "VALUES (SEQ_B_NO.NEXTVAL, ?, SYSDATE, ?, ?)");
		prop.setProperty("SELECT_LIST", "SELECT * FROM PRODUCT ORDER BY NO ASC");
		prop.setProperty("SELECT_BY_ID", "SELECT * FROM PRODUCT WHERE PRODUCT_ID = ?");
		prop.setProperty("SELECT_BY_NAME", "SELECT * FROM PRODUCT WHERE P_NAME LIKE '%' || ? || '%'");
		prop.setProperty("UPDATE_BY_ID", "UPDATE PRODUCT SET P_NAME = ? , PRICE = ? , DESCRIPTION = ? WHERE PRODUCT_ID = ?");
		prop.setProperty("DELETE_BY_ID", "DELETE FROM PRODUCT WHERE PRODUCT_ID = ?");
		prop.setProperty("SELECT_BLIST", "SELECT * FROM BACK_PRODUCT");
		prop.setProperty("SELECT_BY_NO", "SELECT * FROM BACK_PRODUCT WHERE NO = ? ORDER BY NO ASC");

		
		try {
			prop.storeToXML(new FileOutputStream("resources/query.xml"), "Query Statement Setting");
			
			System.out.println("Query Statement Setting 설정파일 query.xml 성공");
		} catch (FileNotFoundException e) {
			System.out.println("파일위치 못찾음");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일내용 입력하는데 문제발생");
			e.printStackTrace();
		}
	}
	
	public static void jdbcGettingXmlTest() {
		Properties prop = new Properties();
		
		try {
			prop.loadFromXML(new FileInputStream("resources/query.xml"));
		
			String INSERT_PRODUCT = prop.getProperty("INSERT_PRODUCT");
			String INSERT_B_PRODUCT = prop.getProperty("INSERT_B_PRODUCT");
			String SELECT_LIST = prop.getProperty("SELECT_LIST");
			String SELECT_BY_ID = prop.getProperty("SELECT_BY_ID");
			String SELECT_BY_NAME = prop.getProperty("SELECT_BY_NAME");
			String UPDATE_BY_ID = prop.getProperty("UPDATE_BY_ID");
			String DELETE_BY_ID = prop.getProperty("DELETE_BY_ID");
			String SELECT_BLIST = prop.getProperty("SELECT_BLIST");
			String SELECT_BY_NO = prop.getProperty("SELECT_BY_NO");
			
			System.out.println("INSERT_PRODUCT : " + INSERT_PRODUCT);
			System.out.println("INSERT_B_PRODUCT : " + INSERT_B_PRODUCT);
			System.out.println("SELECT_LIST : " + SELECT_LIST);
			System.out.println("SELECT_BY_ID : " + SELECT_BY_ID);
			System.out.println("SELECT_BY_NAME : " + SELECT_BY_NAME);
			System.out.println("UPDATE_BY_ID : " + UPDATE_BY_ID);
			System.out.println("DELETE_BY_ID : " + DELETE_BY_ID);
			System.out.println("SELECT_BLIST : " + SELECT_BLIST);
			System.out.println("SELECT_BY_NO : " + SELECT_BY_NO);
			
		} catch (FileNotFoundException e) {
			System.out.println("파일위치 못찾음");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일내용 입력하는데 문제발생");
			e.printStackTrace();
		}
	}
}