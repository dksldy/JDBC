package com.kh.model.vo;

import java.util.Date;

public class Product {
	 	private int No;
	    private String ProductId;
	    private String PName;
	    private int Price;
	    private String Description;
	    private int Stock;
	    private Date ENROLLDATE;
		
	    public Product() {
			super();
		}

		public Product(int no, String productId, String pName, 
				int price, String description, int stock,
				Date eNROLLDATE) {
			super();
			No = no;
			ProductId = productId;
			PName = pName;
			Price = price;
			Description = description;
			Stock = stock;
			ENROLLDATE = eNROLLDATE;
		}

		public int getNo() {
			return No;
		}
		public void setNo(int no) {
			No = no;
		}
		public String getProductId() {
			return ProductId;
		}
		public void setProductId(String productId) {
			ProductId = productId;
		}
		public String getPName() {
			return PName;
		}
		public void setPName(String pName) {
			PName = pName;
		}
		public int getPrice() {
			return Price;
		}
		public void setPrice(int price) {
			Price = price;
		}
		public String getDescription() {
			return Description;
		}
		public void setDescription(String description) {
			Description = description;
		}
		public int getStock() {
			return Stock;
		}
		public void setStock(int stock) {
			Stock = stock;
		}
		public Date getENROLLDATE() {
			return ENROLLDATE;
		}
		public void setENROLLDATE(Date eNROLLDATE) {
			ENROLLDATE = eNROLLDATE;
		}

		@Override
		public String toString() {
			return String.format("등록번호 : %-3d 등록ID : %-10s 제품명 : %-10s 가격 : %-8d 모델명 : %-5s 재고 : %-3d 등록 날짜 : %s",
                    No, ProductId, PName, Price, Description, Stock, ENROLLDATE);
		}
		
		
	    
	    
}
